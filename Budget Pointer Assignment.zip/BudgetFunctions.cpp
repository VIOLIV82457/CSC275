#include "BudgetFunctions.h"
#include <iostream>
#include <iomanip>

using namespace std;

//User Input
void getUserChoice(int* choice)
{
    cout << "\nEnter your choice: ";
    cin >> *choice;
}

//Adding Income
void addIncome(double* totalIncome)
{
    double amount;

    cout << "\nEnter income amount: $";
    cin >> amount;

    *totalIncome += amount;

    cout << "Income added successfully.\n";
}

//Adding Expenses
void addExpense(double* totalExpenses)
{
    double amount;

    cout << "\nEnter expense amount: $";
    cin >> amount;

    *totalExpenses += amount;

    cout << "Expense added successfully.\n";
}

//Balance calculator
void calculateBalance(double* income, double* expenses, double* balance)
{
    *balance = *income - *expenses;
}

void displaySummary(double* income,
                    double* expenses,
                    double* balance)
{
    cout << fixed << setprecision(2);

    cout << "       FINANCIAL SUMMARY\n";

    cout << "Total Income:   $" << *income << endl;
    cout << "Total Expenses: $" << *expenses << endl;
    cout << "Current Balance:$" << *balance << endl;
    
}
//Reset the budget
void resetBudget(double* income, double* expenses, double* balance)
{
    *income = 0.0;
    *expenses = 0.0;
    *balance = 0.0;

    cout << "\nBudget data reset successfully.\n";
}