#ifndef BUDGETFUNCTIONS_H
#define BUDGETFUNCTIONS_H

#include <string>

using namespace std;

// Displays program description
void displayWelcome();

// Gets menu choice
void getUserChoice(int* choice);

// Adds income
void addIncome(double* totalIncome);

// Adds expense
void addExpense(double* totalExpenses);

// Calculates balance
void calculateBalance(double* income,
                      double* expenses,
                      double* balance);

// Displays financial summary
void displaySummary(double* income,
                    double* expenses,
                    double* balance);

// Resets all budget values
void resetBudget(double* income,
                 double* expenses,
                 double* balance);

#endif