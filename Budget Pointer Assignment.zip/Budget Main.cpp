#include <iostream>
#include "BudgetFunctions.h"

using namespace std;

int main()
{
    // Financial variables
    double totalIncome = 0.0;
    double totalExpenses = 0.0;
    double balance = 0.0;

    int choice = 0;

    do
    {
        cout << "================================\n";
        cout << "         MAIN MENU\n";
        cout << "================================\n";
        cout << "1. Add Income\n";
        cout << "2. Add Expense\n";
        cout << "3. Calculate Balance\n";
        cout << "4. View Summary\n";
        cout << "5. Reset Budget\n";
        cout << "6. Exit\n";

        getUserChoice(&choice);

        switch (choice)
        {
        case 1:
            addIncome(&totalIncome);
            break;

        case 2:
            addExpense(&totalExpenses);
            break;

        case 3:
            calculateBalance(&totalIncome,
                             &totalExpenses,
                             &balance);

            cout << "\nBalance calculated.\n";
            break;

        case 4:
            displaySummary(&totalIncome,
                           &totalExpenses,
                           &balance);
            break;

        case 5:
            resetBudget(&totalIncome,
                        &totalExpenses,
                        &balance);
            break;

        case 6:
            cout << "\nThank you for using Budget Tracker!\n";
            break;

        default:
            cout << "\nInvalid choice. Please try again.\n";
        }

    } while (choice != 6);

    return 0;
}